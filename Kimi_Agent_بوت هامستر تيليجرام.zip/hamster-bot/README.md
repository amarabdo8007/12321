# 🐹 Hamster Kombat Bot

بوت تليجرام مشابه لـ Hamster Kombat - لعبة جمع العملات بالنقر على الهامستر!

## 📁 هيكل المشروع

```
hamster-bot/
├── backend/          # باكند البوت (Python)
│   ├── bot.py       # البوت الرئيسي
│   ├── api.py       # API للـ Mini App
│   ├── database.py  # قاعدة البيانات SQLite
│   └── requirements.txt
├── frontend/         # Mini App (React + TypeScript)
│   ├── src/         # كود المصدر
│   ├── public/      # الملفات العامة
│   └── package.json
└── README.md
```

## 🚀 التشغيل

### 1. إعداد البيئة

```bash
# نسخ المشروع
cd hamster-bot

# إنشاء ملف .env في backend
cd backend
echo "BOT_TOKEN=your_bot_token_here" > .env
echo "WEBAPP_URL=https://your-webapp-url.com" >> .env
```

### 2. تشغيل الباكند

```bash
cd backend

# تثبيت المتطلبات
pip install -r requirements.txt

# تشغيل API (في terminal منفصل)
python api.py

# تشغيل البوت (في terminal منفصل)
python bot.py
```

### 3. تشغيل الفرونت

```bash
cd frontend

# تثبيت المتطلبات
npm install

# تشغيل في وضع التطوير
npm run dev

# أو بناء للإنتاج
npm run build
```

## ⚙️ الإعدادات

### إنشاء بوت تليجرام

1. افتح [@BotFather](https://t.me/BotFather)
2. أرسل `/newbot`
3. اتبع التعليمات للحصول على التوكن
4. أرسل `/setdomain` لربط الـ WebApp

### إعداد Mini App

1. في [@BotFather](https://t.me/BotFather)، أرسل `/mybots`
2. اختر بوتك
3. اختر "Bot Settings" → "Menu Button" → "Configure menu button"
4. اضبط الـ URL على رابط الـ WebApp

## 🎮 المميزات

- ✅ نظام نقاط (Coins)
- ✅ نظام طاقة (Energy)
- ✅ نظام مستويات (Levels)
- ✅ متجر تحسينات (Upgrades)
- ✅ نظام دعوات (Referrals)
- ✅ لوحة المتصدرين (Leaderboard)
- ✅ Mini App تفاعلية
- ✅ قاعدة بيانات SQLite

## 📱 لقطات الشاشة

### اللعبة الرئيسية
- انقر على الهامستر لجمع العملات
- شريط طاقة يتجدد تلقائياً
- إحصائيات اللاعب

### متجر التحسينات
- زيادة قوة النقرة
- زيادة الطاقة القصوى
- تسريع تجديد الطاقة

### المتصدرين
- أفضل 100 لاعب
- ترتيب حسب العملات
- إظهار المستوى

## 🔧 المتطلبات

### Backend
- Python 3.8+
- python-telegram-bot
- Flask
- SQLite3

### Frontend
- Node.js 18+
- React 18+
- TypeScript
- Tailwind CSS
- Vite

## 📝 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/user` | POST | Get user data |
| `/api/click` | POST | Handle click |
| `/api/upgrade` | POST | Buy upgrade |
| `/api/leaderboard` | POST | Get leaderboard |
| `/api/energy` | POST | Get current energy |
| `/health` | GET | Health check |

## 🐛 استكشاف الأخطاء

### البوت لا يستجيب
- تأكد من صحة التوكن
- تأكد من تشغيل `bot.py`

### Mini App لا تعمل
- تأكد من تشغيل `api.py`
- تأكد من إعداد `WEBAPP_URL`
- افتح Console المتصفح للتحقق من الأخطاء

### مشاكل قاعدة البيانات
- احذف ملف `hamster.db` لإعادة الإنشاء
- تأكد من صلاحيات الكتابة

## 📄 الترخيص

MIT License - استخدم كما تشاء! 🎉

## 🤝 المساهمة

نرحب بالمساهمات! افتح Issue أو Pull Request.

---

صنع بحب ❤️ للمجتمع العربي
