"""
Flask API for Hamster Bot WebApp
Handles game logic and user interactions
"""
import os
import hmac
import hashlib
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS
from database import (
    get_user, create_user, update_user_stats,
    get_referrals_count, get_leaderboard
)

app = Flask(__name__)
CORS(app)

BOT_TOKEN = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')

def validate_telegram_data(init_data: str) -> dict:
    """Validate Telegram WebApp init data"""
    try:
        # Parse init data
        data_dict = {}
        for pair in init_data.split('&'):
            if '=' in pair:
                key, value = pair.split('=', 1)
                data_dict[key] = value
        
        # Check hash
        if 'hash' not in data_dict:
            return None
        
        received_hash = data_dict.pop('hash')
        
        # Create data check string
        data_check_string = '\n'.join([f"{k}={v}" for k, v in sorted(data_dict.items())])
        
        # Calculate secret key
        secret_key = hmac.new(b'WebAppData', BOT_TOKEN.encode(), hashlib.sha256).digest()
        
        # Calculate hash
        calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        
        if calculated_hash != received_hash:
            return None
        
        # Check auth date (optional - data should be recent)
        if 'auth_date' in data_dict:
            auth_date = int(data_dict['auth_date'])
            if datetime.now().timestamp() - auth_date > 86400:  # 24 hours
                return None
        
        return data_dict
    except Exception as e:
        print(f"Validation error: {e}")
        return None

def parse_user_data(user_str: str) -> dict:
    """Parse user data from Telegram init data"""
    try:
        import json
        # URL decode and parse JSON
        import urllib.parse
        decoded = urllib.parse.unquote(user_str)
        return json.loads(decoded)
    except:
        return {}

def regenerate_energy(user: dict) -> int:
    """Calculate regenerated energy based on time passed"""
    if not user['last_energy_update']:
        return user['energy']
    
    last_update = datetime.fromisoformat(user['last_energy_update'])
    now = datetime.now()
    minutes_passed = (now - last_update).total_seconds() / 60
    
    # Regenerate 1 energy per minute (can be adjusted)
    energy_regenerated = int(minutes_passed * user['energy_regen_rate'])
    new_energy = min(user['energy'] + energy_regenerated, user['max_energy'])
    
    return new_energy

@app.route('/api/user', methods=['POST'])
def get_user_data():
    """Get user data"""
    data = request.json
    init_data = data.get('initData')
    
    if not init_data:
        return jsonify({'error': 'Missing init data'}), 400
    
    validated = validate_telegram_data(init_data)
    if not validated:
        return jsonify({'error': 'Invalid init data'}), 401
    
    user_data = parse_user_data(validated.get('user', '{}'))
    user_id = user_data.get('id')
    
    if not user_id:
        return jsonify({'error': 'User ID not found'}), 400
    
    # Get or create user
    user = get_user(user_id)
    if not user:
        create_user(
            user_id=user_id,
            username=user_data.get('username'),
            first_name=user_data.get('first_name'),
            last_name=user_data.get('last_name')
        )
        user = get_user(user_id)
    
    # Regenerate energy
    user['energy'] = regenerate_energy(user)
    update_user_stats(user_id, energy=user['energy'])
    
    referrals_count = get_referrals_count(user_id)
    
    return jsonify({
        'user': {
            'id': user['user_id'],
            'firstName': user['first_name'],
            'username': user['username'],
            'coins': user['coins'],
            'energy': user['energy'],
            'maxEnergy': user['max_energy'],
            'level': user['level'],
            'xp': user['xp'],
            'coinsPerClick': user['coins_per_click'],
            'energyRegenRate': user['energy_regen_rate'],
            'referrals': referrals_count
        }
    })

@app.route('/api/click', methods=['POST'])
def handle_click():
    """Handle user click"""
    data = request.json
    init_data = data.get('initData')
    
    if not init_data:
        return jsonify({'error': 'Missing init data'}), 400
    
    validated = validate_telegram_data(init_data)
    if not validated:
        return jsonify({'error': 'Invalid init data'}), 401
    
    user_data = parse_user_data(validated.get('user', '{}'))
    user_id = user_data.get('id')
    
    if not user_id:
        return jsonify({'error': 'User ID not found'}), 400
    
    user = get_user(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Regenerate energy first
    user['energy'] = regenerate_energy(user)
    
    # Check if has enough energy
    if user['energy'] < 1:
        return jsonify({'error': 'Not enough energy'}), 400
    
    # Calculate rewards
    coins_earned = user['coins_per_click']
    xp_earned = 1
    
    new_coins = user['coins'] + coins_earned
    new_energy = user['energy'] - 1
    new_xp = user['xp'] + xp_earned
    new_level = user['level']
    
    # Check for level up (every 100 XP)
    xp_needed = user['level'] * 100
    if new_xp >= xp_needed:
        new_level += 1
        new_xp = new_xp - xp_needed
    
    # Update user
    update_user_stats(
        user_id=user_id,
        coins=new_coins,
        energy=new_energy,
        xp=new_xp,
        level=new_level
    )
    
    return jsonify({
        'coins': new_coins,
        'energy': new_energy,
        'maxEnergy': user['max_energy'],
        'level': new_level,
        'xp': new_xp,
        'coinsEarned': coins_earned,
        'xpEarned': xp_earned,
        'leveledUp': new_level > user['level']
    })

@app.route('/api/upgrade', methods=['POST'])
def buy_upgrade():
    """Buy an upgrade"""
    data = request.json
    init_data = data.get('initData')
    upgrade_type = data.get('type')
    
    if not init_data or not upgrade_type:
        return jsonify({'error': 'Missing data'}), 400
    
    validated = validate_telegram_data(init_data)
    if not validated:
        return jsonify({'error': 'Invalid init data'}), 401
    
    user_data = parse_user_data(validated.get('user', '{}'))
    user_id = user_data.get('id')
    
    if not user_id:
        return jsonify({'error': 'User ID not found'}), 400
    
    user = get_user(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Upgrade costs and effects
    upgrades = {
        'click': {
            'base_cost': 100,
            'multiplier': 1.5,
            'effect': lambda u: {'coins_per_click': u['coins_per_click'] + 1}
        },
        'energy': {
            'base_cost': 200,
            'multiplier': 1.8,
            'effect': lambda u: {'max_energy': u['max_energy'] + 100}
        },
        'regen': {
            'base_cost': 500,
            'multiplier': 2.0,
            'effect': lambda u: {'energy_regen_rate': u['energy_regen_rate'] + 1}
        }
    }
    
    if upgrade_type not in upgrades:
        return jsonify({'error': 'Invalid upgrade type'}), 400
    
    upgrade = upgrades[upgrade_type]
    
    # Calculate cost based on current level (simplified)
    # In a real app, you'd track upgrade levels separately
    current_level = user['level']
    cost = int(upgrade['base_cost'] * (upgrade['multiplier'] ** (current_level - 1)))
    
    if user['coins'] < cost:
        return jsonify({'error': 'Not enough coins'}), 400
    
    # Apply upgrade
    effects = upgrade['effect'](user)
    effects['coins'] = user['coins'] - cost
    
    update_user_stats(user_id, **effects)
    
    return jsonify({
        'success': True,
        'cost': cost,
        'newCoins': effects['coins'],
        'effects': effects
    })

@app.route('/api/leaderboard', methods=['POST'])
def get_leaderboard_data():
    """Get leaderboard"""
    data = request.json
    init_data = data.get('initData')
    
    if not init_data:
        return jsonify({'error': 'Missing init data'}), 400
    
    validated = validate_telegram_data(init_data)
    if not validated:
        return jsonify({'error': 'Invalid init data'}), 401
    
    users = get_leaderboard(100)
    
    return jsonify({
        'leaderboard': users
    })

@app.route('/api/energy', methods=['POST'])
def get_energy():
    """Get current energy (for polling)"""
    data = request.json
    init_data = data.get('initData')
    
    if not init_data:
        return jsonify({'error': 'Missing init data'}), 400
    
    validated = validate_telegram_data(init_data)
    if not validated:
        return jsonify({'error': 'Invalid init data'}), 401
    
    user_data = parse_user_data(validated.get('user', '{}'))
    user_id = user_data.get('id')
    
    if not user_id:
        return jsonify({'error': 'User ID not found'}), 400
    
    user = get_user(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Regenerate energy
    new_energy = regenerate_energy(user)
    
    if new_energy != user['energy']:
        update_user_stats(user_id, energy=new_energy)
    
    return jsonify({
        'energy': new_energy,
        'maxEnergy': user['max_energy']
    })

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
