"""
Database module for Hamster Bot
Uses SQLite for storing user data
"""
import sqlite3
import json
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "hamster.db"

def init_db():
    """Initialize the database with required tables"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            coins INTEGER DEFAULT 0,
            energy INTEGER DEFAULT 1000,
            max_energy INTEGER DEFAULT 1000,
            level INTEGER DEFAULT 1,
            xp INTEGER DEFAULT 0,
            coins_per_click INTEGER DEFAULT 1,
            energy_regen_rate INTEGER DEFAULT 1,
            last_energy_update TEXT,
            invited_by INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Upgrades table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS upgrades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            upgrade_type TEXT,
            level INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    ''')
    
    # Referrals table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER,
            referred_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (referrer_id) REFERENCES users(user_id),
            FOREIGN KEY (referred_id) REFERENCES users(user_id)
        )
    ''')
    
    conn.commit()
    conn.close()

def get_user(user_id: int):
    """Get user by ID"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return {
            'user_id': user[0],
            'username': user[1],
            'first_name': user[2],
            'last_name': user[3],
            'coins': user[4],
            'energy': user[5],
            'max_energy': user[6],
            'level': user[7],
            'xp': user[8],
            'coins_per_click': user[9],
            'energy_regen_rate': user[10],
            'last_energy_update': user[11],
            'invited_by': user[12],
            'created_at': user[13]
        }
    return None

def create_user(user_id: int, username: str, first_name: str, last_name: str, invited_by: int = None):
    """Create a new user"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, invited_by, last_energy_update)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (user_id, username, first_name, last_name, invited_by, datetime.now().isoformat()))
    
    conn.commit()
    conn.close()

def update_user_coins(user_id: int, coins: int):
    """Update user coins"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET coins = ? WHERE user_id = ?', (coins, user_id))
    conn.commit()
    conn.close()

def update_user_energy(user_id: int, energy: int):
    """Update user energy"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET energy = ?, last_energy_update = ? WHERE user_id = ?', 
                   (energy, datetime.now().isoformat(), user_id))
    conn.commit()
    conn.close()

def update_user_stats(user_id: int, coins: int = None, energy: int = None, 
                      level: int = None, xp: int = None, coins_per_click: int = None,
                      max_energy: int = None):
    """Update multiple user stats"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    if coins is not None:
        updates.append('coins = ?')
        params.append(coins)
    if energy is not None:
        updates.append('energy = ?')
        params.append(energy)
    if level is not None:
        updates.append('level = ?')
        params.append(level)
    if xp is not None:
        updates.append('xp = ?')
        params.append(xp)
    if coins_per_click is not None:
        updates.append('coins_per_click = ?')
        params.append(coins_per_click)
    if max_energy is not None:
        updates.append('max_energy = ?')
        params.append(max_energy)
    
    if updates:
        params.append(user_id)
        query = f"UPDATE users SET {', '.join(updates)} WHERE user_id = ?"
        cursor.execute(query, params)
        conn.commit()
    
    conn.close()

def add_referral(referrer_id: int, referred_id: int):
    """Add a referral"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT OR IGNORE INTO referrals (referrer_id, referred_id)
        VALUES (?, ?)
    ''', (referrer_id, referred_id))
    
    conn.commit()
    conn.close()

def get_referrals_count(user_id: int) -> int:
    """Get number of referrals for a user"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM referrals WHERE referrer_id = ?', (user_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_leaderboard(limit: int = 100):
    """Get top users by coins"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT user_id, username, first_name, coins, level 
        FROM users 
        ORDER BY coins DESC 
        LIMIT ?
    ''', (limit,))
    users = cursor.fetchall()
    conn.close()
    
    return [{
        'user_id': u[0],
        'username': u[1],
        'first_name': u[2],
        'coins': u[3],
        'level': u[4]
    } for u in users]

# Initialize database on module load
init_db()
