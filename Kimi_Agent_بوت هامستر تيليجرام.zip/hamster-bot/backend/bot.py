"""
Hamster Kombat Telegram Bot
Main bot logic using python-telegram-bot
"""
import os
import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes
from database import (
    get_user, create_user, update_user_stats, 
    add_referral, get_referrals_count, get_leaderboard
)

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot token from environment variable
BOT_TOKEN = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
WEBAPP_URL = os.getenv('WEBAPP_URL', 'https://your-webapp-url.com')

def get_welcome_message(user, referrals_count: int) -> str:
    """Generate welcome message"""
    return f"""
🐹 <b>مرحباً {user['first_name']} في Hamster Kombat!</b>

💰 <b>عملاتك:</b> {user['coins']:,}
⚡ <b>الطاقة:</b> {user['energy']}/{user['max_energy']}
⭐ <b>المستوى:</b> {user['level']}
👥 <b>الدعوات:</b> {referrals_count}

🎮 <b>اضغط على الزر أدناه للعب!</b>
"""

def get_main_keyboard():
    """Generate main keyboard with WebApp button"""
    keyboard = [
        [InlineKeyboardButton("🎮 العب الآن", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton("📊 المتصدرين", callback_data='leaderboard')],
        [InlineKeyboardButton("👥 دعوة أصدقاء", callback_data='invite')],
        [InlineKeyboardButton("ℹ️ المساعدة", callback_data='help')]
    ]
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user = update.effective_user
    
    # Check for referral
    invited_by = None
    if context.args and len(context.args) > 0:
        try:
            invited_by = int(context.args[0])
            if invited_by == user.id:
                invited_by = None
        except ValueError:
            pass
    
    # Create or get user
    db_user = get_user(user.id)
    if not db_user:
        create_user(
            user_id=user.id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name,
            invited_by=invited_by
        )
        
        # Add referral if exists
        if invited_by:
            add_referral(invited_by, user.id)
            # Give bonus to referrer
            referrer = get_user(invited_by)
            if referrer:
                update_user_stats(invited_by, coins=referrer['coins'] + 500)
                await context.bot.send_message(
                    chat_id=invited_by,
                    text=f"🎉 <b>مبروك!</b> لقد انضم صديقك {user.first_name}!
💰 حصلت على <b>500</b> عملة مكافأة!"
                )
        
        db_user = get_user(user.id)
    
    referrals_count = get_referrals_count(user.id)
    
    await update.message.reply_text(
        get_welcome_message(db_user, referrals_count),
        reply_markup=get_main_keyboard(),
        parse_mode='HTML'
    )

async def play(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /play command"""
    await start(update, context)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /stats command"""
    user = update.effective_user
    db_user = get_user(user.id)
    
    if not db_user:
        await update.message.reply_text(
            "❌ أنت غير مسجل. اضغط /start للبدء",
            parse_mode='HTML'
        )
        return
    
    referrals_count = get_referrals_count(user.id)
    
    stats_text = f"""
📊 <b>إحصائياتك:</b>

👤 <b>الاسم:</b> {db_user['first_name']}
💰 <b>العملات:</b> {db_user['coins']:,}
⚡ <b>الطاقة:</b> {db_user['energy']}/{db_user['max_energy']}
⭐ <b>المستوى:</b> {db_user['level']}
📈 <b>الخبرة:</b> {db_user['xp']}
💵 <b>العملات لكل نقرة:</b> {db_user['coins_per_click']}
👥 <b>الدعوات:</b> {referrals_count}
📅 <b>تاريخ الانضمام:</b> {db_user['created_at'][:10]}
"""
    
    await update.message.reply_text(stats_text, parse_mode='HTML')

async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /leaderboard command"""
    users = get_leaderboard(10)
    
    if not users:
        await update.message.reply_text("❌ لا يوجد لاعبين بعد!")
        return
    
    text = "🏆 <b>أفضل 10 لاعبين:</b>\n\n"
    
    medals = ['🥇', '🥈', '🥉']
    for i, user in enumerate(users, 1):
        medal = medals[i-1] if i <= 3 else f"{i}."
        name = user['first_name'] or user['username'] or f"Player {user['user_id']}"
        text += f"{medal} <b>{name}</b> - 💰 {user['coins']:,} (Lvl {user['level']})\n"
    
    await update.message.reply_text(text, parse_mode='HTML')

async def invite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /invite command"""
    user = update.effective_user
    bot_username = (await context.bot.get_me()).username
    invite_link = f"https://t.me/{bot_username}?start={user.id}"
    
    referrals_count = get_referrals_count(user.id)
    
    text = f"""
👥 <b>دعوة الأصدقاء</b>

🔗 <b>رابط الدعوة:</b>
<code>{invite_link}</code>

👤 <b>عدد الدعوات:</b> {referrals_count}

💰 <b>احصل على 500 عملة</b> لكل صديق يدعوه!

📤 <b>شارك الرابط مع أصدقائك</b>
"""
    
    keyboard = [[InlineKeyboardButton("📤 مشاركة", url=f"https://t.me/share/url?url={invite_link}&text=انضم%20إلي%20في%20لعبة%20Hamster%20Kombat!")]]
    
    await update.message.reply_text(
        text, 
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    help_text = """
ℹ️ <b>كيفية اللعب:</b>

1️⃣ اضغط على "العب الآن" لفتح اللعبة
2️⃣ انقر على الهامستر لجمع العملات
3️⃣ استخدم العملات لشراء التحسينات
4️⃣ ارفع مستواك لزيادة أرباحك
5️⃣ ادعُ أصدقاءك للحصول على مكافآت

⚡ <b>نظام الطاقة:</b>
- كل نقرة تستهلك طاقة
- الطاقة تتجدد مع الوقت
- يمكنك زيادة الطاقة القصوى بالترقيات

⭐ <b>نظام المستويات:</b>
- اجمع XP لرفع مستواك
- كل مستوى يعطيك مكافآت
- فتح تحسينات جديدة

🎮 <b>الأوامر:</b>
/start - بدء البوت
/play - فتح اللعبة
/stats - إحصائياتك
/leaderboard - المتصدرين
/invite - دعوة أصدقاء
/help - المساعدة
"""
    
    await update.message.reply_text(help_text, parse_mode='HTML')

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'leaderboard':
        users = get_leaderboard(10)
        
        if not users:
            await query.edit_message_text("❌ لا يوجد لاعبين بعد!")
            return
        
        text = "🏆 <b>أفضل 10 لاعبين:</b>\n\n"
        
        medals = ['🥇', '🥈', '🥉']
        for i, user in enumerate(users, 1):
            medal = medals[i-1] if i <= 3 else f"{i}."
            name = user['first_name'] or user['username'] or f"Player {user['user_id']}"
            text += f"{medal} <b>{name}</b> - 💰 {user['coins']:,} (Lvl {user['level']})\n"
        
        keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data='back')]]
        await query.edit_message_text(text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
    
    elif query.data == 'invite':
        user = update.effective_user
        bot_username = (await context.bot.get_me()).username
        invite_link = f"https://t.me/{bot_username}?start={user.id}"
        referrals_count = get_referrals_count(user.id)
        
        text = f"""
👥 <b>دعوة الأصدقاء</b>

🔗 <b>رابط الدعوة:</b>
<code>{invite_link}</code>

👤 <b>عدد الدعوات:</b> {referrals_count}

💰 <b>احصل على 500 عملة</b> لكل صديق يدعوه!
"""
        keyboard = [
            [InlineKeyboardButton("📤 مشاركة", url=f"https://t.me/share/url?url={invite_link}&text=انضم%20إلي%20في%20لعبة%20Hamster%20Kombat!")],
            [InlineKeyboardButton("🔙 رجوع", callback_data='back')]
        ]
        await query.edit_message_text(text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
    
    elif query.data == 'help':
        help_text = """
ℹ️ <b>كيفية اللعب:</b>

1️⃣ اضغط على "العب الآن" لفتح اللعبة
2️⃣ انقر على الهامستر لجمع العملات
3️⃣ استخدم العملات لشراء التحسينات
4️⃣ ارفع مستواك لزيادة أرباحك

⚡ <b>نظام الطاقة:</b>
- كل نقرة تستهلك طاقة
- الطاقة تتجدد مع الوقت

⭐ <b>نظام المستويات:</b>
- اجمع XP لرفع مستواك
- كل مستوى يعطيك مكافآت
"""
        keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data='back')]]
        await query.edit_message_text(help_text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
    
    elif query.data == 'back':
        user = update.effective_user
        db_user = get_user(user.id)
        referrals_count = get_referrals_count(user.id)
        
        await query.edit_message_text(
            get_welcome_message(db_user, referrals_count),
            reply_markup=get_main_keyboard(),
            parse_mode='HTML'
        )

def main():
    """Start the bot"""
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("play", play))
    application.add_handler(CommandHandler("stats", stats))
    application.add_handler(CommandHandler("leaderboard", leaderboard))
    application.add_handler(CommandHandler("invite", invite))
    application.add_handler(CommandHandler("help", help_command))
    
    # Callback handler
    application.add_handler(CommandHandler("callback_query", button_callback))
    
    # Start the bot
    print("🤖 Bot is running...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
