import { useState, useEffect, useCallback } from 'react';
import { User, ClickResponse, UpgradeResponse, LeaderboardUser } from '@/types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export function useGame(initData: string) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);

  // Fetch user data
  const fetchUser = useCallback(async () => {
    if (!initData) return;
    
    try {
      const response = await fetch(`${API_URL}/api/user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ initData })
      });
      
      if (!response.ok) throw new Error('Failed to fetch user');
      
      const data = await response.json();
      setUser(data.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [initData]);

  // Initial load
  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  // Poll energy every 10 seconds
  useEffect(() => {
    if (!initData) return;
    
    const interval = setInterval(async () => {
      try {
        const response = await fetch(`${API_URL}/api/energy`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ initData })
        });
        
        if (response.ok) {
          const data = await response.json();
          setUser(prev => prev ? { ...prev, energy: data.energy, maxEnergy: data.maxEnergy } : null);
        }
      } catch (err) {
        console.error('Energy poll error:', err);
      }
    }, 10000);
    
    return () => clearInterval(interval);
  }, [initData]);

  // Handle click
  const click = useCallback(async (): Promise<ClickResponse | null> => {
    if (!initData) return null;
    
    try {
      const response = await fetch(`${API_URL}/api/click`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ initData })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Click failed');
      }
      
      const data = await response.json();
      
      setUser(prev => prev ? {
        ...prev,
        coins: data.coins,
        energy: data.energy,
        level: data.level,
        xp: data.xp
      } : null);
      
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Click failed');
      return null;
    }
  }, [initData]);

  // Buy upgrade
  const buyUpgrade = useCallback(async (type: string): Promise<UpgradeResponse | null> => {
    if (!initData) return null;
    
    try {
      const response = await fetch(`${API_URL}/api/upgrade`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ initData, type })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Upgrade failed');
      }
      
      const data = await response.json();
      
      // Refresh user data after upgrade
      await fetchUser();
      
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upgrade failed');
      return null;
    }
  }, [initData, fetchUser]);

  // Fetch leaderboard
  const fetchLeaderboard = useCallback(async () => {
    if (!initData) return;
    
    try {
      const response = await fetch(`${API_URL}/api/leaderboard`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ initData })
      });
      
      if (!response.ok) throw new Error('Failed to fetch leaderboard');
      
      const data = await response.json();
      setLeaderboard(data.leaderboard);
    } catch (err) {
      console.error('Leaderboard error:', err);
    }
  }, [initData]);

  return {
    user,
    loading,
    error,
    leaderboard,
    click,
    buyUpgrade,
    fetchLeaderboard,
    refreshUser: fetchUser
  };
}
