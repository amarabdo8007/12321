import { useEffect, useState } from 'react';
import { TelegramUser } from '@/types';

declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string;
        initDataUnsafe: {
          user?: TelegramUser;
          query_id?: string;
        };
        ready: () => void;
        expand: () => void;
        close: () => void;
        MainButton: {
          text: string;
          show: () => void;
          hide: () => void;
          onClick: (callback: () => void) => void;
        };
        BackButton: {
          show: () => void;
          hide: () => void;
          onClick: (callback: () => void) => void;
        };
        HapticFeedback: {
          impactOccurred: (style: 'light' | 'medium' | 'heavy') => void;
          notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
        };
        setHeaderColor: (color: string) => void;
        setBackgroundColor: (color: string) => void;
      };
    };
  }
}

export function useTelegram() {
  const [initData, setInitData] = useState<string>('');
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (window.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp;
      
      // Initialize WebApp
      tg.ready();
      tg.expand();
      
      // Set colors
      tg.setHeaderColor('#1a1a2e');
      tg.setBackgroundColor('#1a1a2e');
      
      // Get init data
      setInitData(tg.initData);
      setUser(tg.initDataUnsafe.user || null);
      setIsReady(true);
    }
  }, []);

  const hapticImpact = (style: 'light' | 'medium' | 'heavy' = 'medium') => {
    window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(style);
  };

  const hapticNotification = (type: 'error' | 'success' | 'warning' = 'success') => {
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred(type);
  };

  const closeWebApp = () => {
    window.Telegram?.WebApp?.close();
  };

  return {
    initData,
    user,
    isReady,
    hapticImpact,
    hapticNotification,
    closeWebApp,
    webApp: window.Telegram?.WebApp
  };
}
