import { useState, useEffect } from 'react';
import { useTelegram } from '@/hooks/useTelegram';
import { useGame } from '@/hooks/useGame';
import { StatsBar } from '@/components/StatsBar';
import { Hamster } from '@/components/Hamster';
import { Upgrades } from '@/components/Upgrades';
import { Leaderboard } from '@/components/Leaderboard';
import { Friends } from '@/components/Friends';
import { Navigation } from '@/components/Navigation';
import { LevelUpModal } from '@/components/LevelUpModal';
import { TabType } from '@/types';
import { Loader2, AlertCircle } from 'lucide-react';
import './App.css';

function App() {
  const { initData, isReady } = useTelegram();
  const { user, loading, error, leaderboard, click, buyUpgrade, fetchLeaderboard } = useGame(initData);
  const [activeTab, setActiveTab] = useState<TabType>('game');
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [newLevel, setNewLevel] = useState(0);

  // Handle level up
  const handleClick = async () => {
    const result = await click();
    if (result?.leveledUp) {
      setNewLevel(result.level);
      setShowLevelUp(true);
    }
    return result;
  };

  // Loading state
  if (!isReady || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#1a1a2e] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-400 animate-spin mx-auto mb-4" />
          <p className="text-gray-400">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#1a1a2e] flex items-center justify-center p-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">حدث خطأ</h2>
          <p className="text-gray-400 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-purple-500 text-white rounded-xl font-medium hover:bg-purple-600 transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  // No user data
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#1a1a2e] flex items-center justify-center p-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">لم يتم العثور على المستخدم</h2>
          <p className="text-gray-400">يرجى فتح اللعبة من خلال بوت تليجرام</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#1a1a2e] text-white">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#0a0a0f]/80 backdrop-blur-md border-b border-white/10 px-4 py-3">
        <div className="max-w-md mx-auto">
          <h1 className="text-xl font-bold text-center bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            🐹 Hamster Kombat
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 pb-24 pt-4">
        {/* Stats Bar - Always visible */}
        <div className="mb-6">
          <StatsBar user={user} />
        </div>

        {/* Tab Content */}
        {activeTab === 'game' && (
          <div className="space-y-6">
            {/* Welcome Message */}
            <div className="text-center">
              <p className="text-gray-400">
                مرحباً، <span className="text-white font-medium">{user.firstName}</span>! 👋
              </p>
              <p className="text-sm text-gray-500 mt-1">
                انقر على الهامستر لجمع العملات!
              </p>
            </div>

            {/* Hamster */}
            <Hamster 
              onClick={handleClick} 
              disabled={user.energy < 1} 
            />

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#1a1a2e] rounded-xl p-4 text-center border border-white/10">
                <p className="text-2xl font-bold text-yellow-400">{user.coinsPerClick}</p>
                <p className="text-xs text-gray-500">عملة/نقرة</p>
              </div>
              <div className="bg-[#1a1a2e] rounded-xl p-4 text-center border border-white/10">
                <p className="text-2xl font-bold text-green-400">{user.energyRegenRate}</p>
                <p className="text-xs text-gray-500">تجدد/دقيقة</p>
              </div>
            </div>

            {/* Tips */}
            <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-4 border border-purple-500/20">
              <h3 className="font-bold text-purple-400 mb-2">💡 نصائح</h3>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• اجمع العملات واشترِ التحسينات</li>
                <li>• الطاقة تتجدد تلقائياً مع الوقت</li>
                <li>• ادعُ أصدقاءك للحصول على مكافآت</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'upgrades' && (
          <Upgrades user={user} onBuyUpgrade={buyUpgrade} />
        )}

        {activeTab === 'leaderboard' && (
          <Leaderboard 
            leaderboard={leaderboard} 
            currentUserId={user.id}
            onRefresh={fetchLeaderboard}
          />
        )}

        {activeTab === 'friends' && (
          <Friends user={user} />
        )}
      </main>

      {/* Navigation */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Level Up Modal */}
      {showLevelUp && (
        <LevelUpModal 
          level={newLevel} 
          onClose={() => setShowLevelUp(false)} 
        />
      )}
    </div>
  );
}

export default App;
