import { useState } from 'react';
import { MousePointer, Zap, Battery, TrendingUp, Lock, Check } from 'lucide-react';
import { User } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface UpgradesProps {
  user: User;
  onBuyUpgrade: (type: string) => Promise<{ success: boolean; cost: number } | null>;
}

interface Upgrade {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  icon: React.ReactNode;
  baseCost: number;
  multiplier: number;
  effect: string;
  color: string;
}

const upgrades: Upgrade[] = [
  {
    id: 'click',
    name: 'Click Power',
    nameAr: 'قوة النقرة',
    description: 'زيادة العملات المكتسبة لكل نقرة',
    icon: <MousePointer className="w-6 h-6" />,
    baseCost: 100,
    multiplier: 1.5,
    effect: '+1 عملة/نقرة',
    color: 'from-yellow-400 to-orange-500'
  },
  {
    id: 'energy',
    name: 'Max Energy',
    nameAr: 'الطاقة القصوى',
    description: 'زيادة الحد الأقصى للطاقة',
    icon: <Battery className="w-6 h-6" />,
    baseCost: 200,
    multiplier: 1.8,
    effect: '+100 طاقة',
    color: 'from-green-400 to-emerald-500'
  },
  {
    id: 'regen',
    name: 'Energy Regen',
    nameAr: 'تجدد الطاقة',
    description: 'زيادة سرعة تجديد الطاقة',
    icon: <Zap className="w-6 h-6" />,
    baseCost: 500,
    multiplier: 2.0,
    effect: '+1/دقيقة',
    color: 'from-blue-400 to-cyan-500'
  }
];

export function Upgrades({ user, onBuyUpgrade }: UpgradesProps) {
  const [selectedUpgrade, setSelectedUpgrade] = useState<Upgrade | null>(null);
  const [buying, setBuying] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const calculateCost = (upgrade: Upgrade) => {
    return Math.floor(upgrade.baseCost * Math.pow(upgrade.multiplier, user.level - 1));
  };

  const handleBuy = async () => {
    if (!selectedUpgrade) return;
    
    setBuying(true);
    const result = await onBuyUpgrade(selectedUpgrade.id);
    setBuying(false);
    
    if (result) {
      if (result.success) {
        setMessage(`✅ تم الشراء بنجاح!`);
      } else {
        setMessage('❌ فشل الشراء');
      }
      setTimeout(() => setMessage(null), 2000);
    }
    
    setSelectedUpgrade(null);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white text-center mb-4">🛒 متجر التحسينات</h2>
      
      {message && (
        <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-3 text-center">
          <p className="text-green-400 font-medium">{message}</p>
        </div>
      )}
      
      <div className="grid gap-3">
        {upgrades.map(upgrade => {
          const cost = calculateCost(upgrade);
          const canAfford = user.coins >= cost;
          
          return (
            <button
              key={upgrade.id}
              onClick={() => setSelectedUpgrade(upgrade)}
              disabled={!canAfford}
              className={`
                relative p-4 rounded-xl border transition-all
                ${canAfford 
                  ? 'bg-gradient-to-r from-[#1a1a2e] to-[#16213e] border-white/20 hover:border-white/40' 
                  : 'bg-gray-800/50 border-gray-700 opacity-60'
                }
              `}
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${upgrade.color} flex items-center justify-center`}>
                  {upgrade.icon}
                </div>
                
                <div className="flex-1 text-left">
                  <h3 className="font-bold text-white">{upgrade.nameAr}</h3>
                  <p className="text-xs text-gray-400">{upgrade.description}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs bg-white/10 px-2 py-0.5 rounded text-gray-300">
                      {upgrade.effect}
                    </span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`flex items-center gap-1 ${canAfford ? 'text-yellow-400' : 'text-red-400'}`}>
                    <span className="font-bold">{cost.toLocaleString()}</span>
                    <span className="text-xs">🪙</span>
                  </div>
                  {!canAfford && <Lock className="w-4 h-4 text-red-400 mx-auto mt-1" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>
      
      {/* Current Stats */}
      <div className="mt-6 p-4 bg-[#1a1a2e] rounded-xl border border-white/10">
        <h3 className="text-sm font-medium text-gray-400 mb-3">📊 إحصائياتك الحالية</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-yellow-400">{user.coinsPerClick}</p>
            <p className="text-xs text-gray-500">عملة/نقرة</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-green-400">{user.maxEnergy}</p>
            <p className="text-xs text-gray-500">طاقة قصوى</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-blue-400">{user.energyRegenRate}</p>
            <p className="text-xs text-gray-500">تجدد/دقيقة</p>
          </div>
        </div>
      </div>
      
      {/* Buy Dialog */}
      <Dialog open={!!selectedUpgrade} onOpenChange={() => setSelectedUpgrade(null)}>
        <DialogContent className="bg-[#1a1a2e] border-white/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">
              {selectedUpgrade?.nameAr}
            </DialogTitle>
            <DialogDescription className="text-center text-gray-400">
              {selectedUpgrade?.description}
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex justify-center py-4">
            <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${selectedUpgrade?.color} flex items-center justify-center`}>
              {selectedUpgrade?.icon}
            </div>
          </div>
          
          <div className="text-center space-y-2">
            <p className="text-gray-400">التكلفة</p>
            <p className="text-3xl font-bold text-yellow-400">
              {selectedUpgrade ? calculateCost(selectedUpgrade).toLocaleString() : 0} 🪙
            </p>
          </div>
          
          <div className="flex gap-3 mt-4">
            <Button
              variant="outline"
              onClick={() => setSelectedUpgrade(null)}
              className="flex-1 border-white/20 text-white hover:bg-white/10"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleBuy}
              disabled={buying}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white"
            >
              {buying ? 'جاري الشراء...' : 'شراء'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
