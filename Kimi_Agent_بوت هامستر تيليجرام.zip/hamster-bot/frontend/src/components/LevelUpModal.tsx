import { useEffect, useState } from 'react';
import { Star, Sparkles, X } from 'lucide-react';

interface LevelUpModalProps {
  level: number;
  onClose: () => void;
}

export function LevelUpModal({ level, onClose }: LevelUpModalProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Small delay for animation
    setTimeout(() => setShow(true), 100);
    
    // Auto close after 3 seconds
    const timer = setTimeout(() => {
      handleClose();
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setShow(false);
    setTimeout(onClose, 300);
  };

  return (
    <div 
      className={`
        fixed inset-0 z-50 flex items-center justify-center p-4
        transition-opacity duration-300
        ${show ? 'opacity-100' : 'opacity-0 pointer-events-none'}
      `}
    >
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={handleClose}
      />
      
      {/* Modal */}
      <div 
        className={`
          relative bg-gradient-to-br from-purple-600 to-pink-600 rounded-3xl p-8 text-center
          transform transition-all duration-500
          ${show ? 'scale-100 translate-y-0' : 'scale-50 translate-y-10'}
        `}
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
        
        {/* Sparkles */}
        <div className="absolute -top-4 -left-4 animate-bounce">
          <Sparkles className="w-8 h-8 text-yellow-300" />
        </div>
        <div className="absolute -top-4 -right-4 animate-bounce delay-100">
          <Sparkles className="w-8 h-8 text-yellow-300" />
        </div>
        <div className="absolute -bottom-4 -left-4 animate-bounce delay-200">
          <Sparkles className="w-8 h-8 text-yellow-300" />
        </div>
        <div className="absolute -bottom-4 -right-4 animate-bounce delay-300">
          <Sparkles className="w-8 h-8 text-yellow-300" />
        </div>
        
        {/* Content */}
        <div className="relative">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center animate-pulse">
            <Star className="w-12 h-12 text-white" />
          </div>
          
          <h2 className="text-3xl font-bold text-white mb-2">
            مبروك! 🎉
          </h2>
          
          <p className="text-white/80 mb-4">
            لقد وصلت إلى المستوى
          </p>
          
          <div className="text-6xl font-bold text-yellow-300 mb-4">
            {level}
          </div>
          
          <div className="space-y-2 text-white/70 text-sm">
            <p>✨ مكافآت جديدة متاحة!</p>
            <p>💪 قوة النقرة زادت!</p>
            <p>⚡ الطاقة القصوى زادت!</p>
          </div>
        </div>
      </div>
    </div>
  );
}
