import { Coins, Zap, Star, Users } from 'lucide-react';
import { User } from '@/types';

interface StatsBarProps {
  user: User;
}

export function StatsBar({ user }: StatsBarProps) {
  const energyPercent = (user.energy / user.maxEnergy) * 100;
  
  // Calculate XP progress
  const xpNeeded = user.level * 100;
  const xpPercent = (user.xp / xpNeeded) * 100;

  return (
    <div className="bg-gradient-to-r from-[#1a1a2e] to-[#16213e] rounded-xl p-4 shadow-lg border border-white/10">
      {/* Coins and Level */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg">
            <Coins className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs text-gray-400">العملات</p>
            <p className="text-lg font-bold text-yellow-400">{user.coins.toLocaleString()}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center shadow-lg">
            <Star className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs text-gray-400">المستوى</p>
            <p className="text-lg font-bold text-purple-400">{user.level}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-cyan-500 flex items-center justify-center shadow-lg">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs text-gray-400">الدعوات</p>
            <p className="text-lg font-bold text-blue-400">{user.referrals}</p>
          </div>
        </div>
      </div>
      
      {/* Energy Bar */}
      <div className="mb-2">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1">
            <Zap className="w-4 h-4 text-green-400" />
            <span className="text-xs text-gray-400">الطاقة</span>
          </div>
          <span className="text-xs text-green-400 font-medium">
            {user.energy}/{user.maxEnergy}
          </span>
        </div>
        <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-green-400 to-emerald-500 transition-all duration-500"
            style={{ width: `${energyPercent}%` }}
          />
        </div>
      </div>
      
      {/* XP Bar */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-gray-400">الخبرة</span>
          </div>
          <span className="text-xs text-purple-400 font-medium">
            {user.xp}/{xpNeeded} XP
          </span>
        </div>
        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-purple-400 to-pink-500 transition-all duration-500"
            style={{ width: `${xpPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
}
