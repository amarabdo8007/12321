import { useState, useCallback } from 'react';
import { useTelegram } from '@/hooks/useTelegram';

interface HamsterProps {
  onClick: () => Promise<{ coinsEarned: number; xpEarned: number; leveledUp: boolean } | null>;
  disabled: boolean;
}

interface FloatingText {
  id: number;
  x: number;
  y: number;
  coins: number;
  xp: number;
}

export function Hamster({ onClick, disabled }: HamsterProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const { hapticImpact, hapticNotification } = useTelegram();

  const handleClick = useCallback(async (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Haptic feedback
    hapticImpact('light');
    
    // Visual feedback
    setIsPressed(true);
    setTimeout(() => setIsPressed(false), 100);
    
    // Call API
    const result = await onClick();
    
    if (result) {
      // Add floating text
      const newText: FloatingText = {
        id: Date.now(),
        x,
        y,
        coins: result.coinsEarned,
        xp: result.xpEarned
      };
      
      setFloatingTexts(prev => [...prev, newText]);
      
      // Remove floating text after animation
      setTimeout(() => {
        setFloatingTexts(prev => prev.filter(t => t.id !== newText.id));
      }, 1000);
      
      // Level up notification
      if (result.leveledUp) {
        hapticNotification('success');
      }
    }
  }, [onClick, disabled, hapticImpact, hapticNotification]);

  return (
    <div className="relative flex items-center justify-center py-8">
      {/* Glow effect */}
      <div className="absolute w-64 h-64 rounded-full bg-gradient-to-r from-yellow-400/20 to-orange-500/20 blur-3xl" />
      
      {/* Floating texts */}
      {floatingTexts.map(text => (
        <div
          key={text.id}
          className="absolute pointer-events-none animate-float-up z-20"
          style={{ left: text.x - 30, top: text.y - 50 }}
        >
          <div className="flex flex-col items-center">
            <span className="text-yellow-400 font-bold text-xl drop-shadow-lg">+{text.coins}</span>
            <span className="text-purple-400 font-medium text-sm">+{text.xp} XP</span>
          </div>
        </div>
      ))}
      
      {/* Hamster button */}
      <button
        onClick={handleClick}
        disabled={disabled}
        className={`
          relative w-56 h-56 rounded-full transition-all duration-100
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
          ${isPressed ? 'scale-95' : 'scale-100 hover:scale-105'}
        `}
      >
        {/* Outer ring */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-400 via-orange-400 to-orange-600 p-1">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-amber-300 to-orange-500 flex items-center justify-center">
            {/* Hamster face */}
            <div className="relative w-44 h-44">
              {/* Ears */}
              <div className="absolute -top-2 left-4 w-12 h-12 rounded-full bg-amber-400 border-4 border-orange-500" />
              <div className="absolute -top-2 right-4 w-12 h-12 rounded-full bg-amber-400 border-4 border-orange-500" />
              
              {/* Face */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-amber-200 to-amber-400 border-4 border-orange-500">
                {/* Eyes */}
                <div className="absolute top-12 left-10 w-10 h-10 rounded-full bg-white flex items-center justify-center">
                  <div className="w-5 h-5 rounded-full bg-gray-900" />
                </div>
                <div className="absolute top-12 right-10 w-10 h-10 rounded-full bg-white flex items-center justify-center">
                  <div className="w-5 h-5 rounded-full bg-gray-900" />
                </div>
                
                {/* Nose */}
                <div className="absolute top-20 left-1/2 -translate-x-1/2 w-6 h-5 rounded-full bg-pink-400" />
                
                {/* Mouth */}
                <div className="absolute top-26 left-1/2 -translate-x-1/2 w-8 h-4 border-b-4 border-gray-800 rounded-full" />
                
                {/* Cheeks */}
                <div className="absolute top-18 left-4 w-8 h-6 rounded-full bg-pink-300/60" />
                <div className="absolute top-18 right-4 w-8 h-6 rounded-full bg-pink-300/60" />
                
                {/* Whiskers */}
                <div className="absolute top-20 left-0 w-8 h-0.5 bg-gray-600 rotate-12" />
                <div className="absolute top-24 left-0 w-8 h-0.5 bg-gray-600" />
                <div className="absolute top-20 right-0 w-8 h-0.5 bg-gray-600 -rotate-12" />
                <div className="absolute top-24 right-0 w-8 h-0.5 bg-gray-600" />
              </div>
              
              {/* Paws */}
              <div className="absolute bottom-4 left-8 w-10 h-10 rounded-full bg-amber-300 border-2 border-orange-500" />
              <div className="absolute bottom-4 right-8 w-10 h-10 rounded-full bg-amber-300 border-2 border-orange-500" />
            </div>
          </div>
        </div>
        
        {/* Shine effect */}
        <div className="absolute top-6 left-8 w-16 h-8 rounded-full bg-white/30 -rotate-45" />
      </button>
      
      {/* Click hint */}
      {disabled && (
        <div className="absolute bottom-0 text-center">
          <p className="text-red-400 text-sm font-medium">⚡ الطاقة منخفضة!</p>
          <p className="text-gray-400 text-xs">انتظر حتى تتجدد</p>
        </div>
      )}
    </div>
  );
}
