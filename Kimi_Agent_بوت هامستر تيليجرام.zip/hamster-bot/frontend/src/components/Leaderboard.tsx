import { useEffect } from 'react';
import { Trophy, Medal, Crown, User } from 'lucide-react';
import { LeaderboardUser } from '@/types';

interface LeaderboardProps {
  leaderboard: LeaderboardUser[];
  currentUserId: number;
  onRefresh: () => void;
}

export function Leaderboard({ leaderboard, currentUserId, onRefresh }: LeaderboardProps) {
  useEffect(() => {
    onRefresh();
  }, [onRefresh]);

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Crown className="w-6 h-6 text-yellow-400" />;
      case 1:
        return <Medal className="w-6 h-6 text-gray-300" />;
      case 2:
        return <Medal className="w-6 h-6 text-amber-600" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-gray-400 font-bold">{index + 1}</span>;
    }
  };

  const getRankStyle = (index: number) => {
    switch (index) {
      case 0:
        return 'bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/50';
      case 1:
        return 'bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-400/50';
      case 2:
        return 'bg-gradient-to-r from-amber-600/20 to-amber-700/20 border-amber-600/50';
      default:
        return 'bg-[#1a1a2e] border-white/10';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Trophy className="w-6 h-6 text-yellow-400" />
          المتصدرين
        </h2>
        <button
          onClick={onRefresh}
          className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
        >
          تحديث
        </button>
      </div>

      {leaderboard.length === 0 ? (
        <div className="text-center py-12">
          <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">لا يوجد لاعبين بعد!</p>
          <p className="text-sm text-gray-500">كن أول من ينضم</p>
        </div>
      ) : (
        <div className="space-y-2">
          {leaderboard.map((player, index) => {
            const isCurrentUser = player.user_id === currentUserId;
            const displayName = player.first_name || player.username || `لاعب ${player.user_id}`;
            
            return (
              <div
                key={player.user_id}
                className={`
                  flex items-center gap-3 p-3 rounded-xl border transition-all
                  ${getRankStyle(index)}
                  ${isCurrentUser ? 'ring-2 ring-blue-500/50' : ''}
                `}
              >
                {/* Rank */}
                <div className="flex-shrink-0">
                  {getRankIcon(index)}
                </div>
                
                {/* Avatar */}
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-white" />
                </div>
                
                {/* Name */}
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white truncate">
                    {displayName}
                    {isCurrentUser && (
                      <span className="ml-2 text-xs bg-blue-500/30 text-blue-300 px-2 py-0.5 rounded">
                        أنت
                      </span>
                    )}
                  </p>
                  <p className="text-xs text-gray-400">المستوى {player.level}</p>
                </div>
                
                {/* Coins */}
                <div className="text-right">
                  <p className="font-bold text-yellow-400">
                    {player.coins.toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500">🪙</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Stats summary */}
      <div className="mt-6 p-4 bg-[#1a1a2e] rounded-xl border border-white/10">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-white">{leaderboard.length}</p>
            <p className="text-xs text-gray-500">لاعب</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-yellow-400">
              {leaderboard[0]?.coins.toLocaleString() || 0}
            </p>
            <p className="text-xs text-gray-500">أعلى رصيد</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-purple-400">
              {leaderboard[0]?.level || 1}
            </p>
            <p className="text-xs text-gray-500">أعلى مستوى</p>
          </div>
        </div>
      </div>
    </div>
  );
}
