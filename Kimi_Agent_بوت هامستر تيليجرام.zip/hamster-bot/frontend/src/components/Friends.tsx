import { Users, Copy, Share2, Gift } from 'lucide-react';
import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { useTelegram } from '@/hooks/useTelegram';

interface FriendsProps {
  user: User;
}

export function Friends({ user }: FriendsProps) {
  const { webApp, user: tgUser } = useTelegram();
  
  // Generate invite link
  const botUsername = 'your_bot_username'; // Will be replaced
  const inviteLink = `https://t.me/${botUsername}?start=${user.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(inviteLink);
    webApp?.HapticFeedback?.notificationOccurred('success');
  };

  const handleShare = () => {
    const text = `انضم إلي في لعبة Hamster Kombat! 🐹\n\nادعُك للعب معي والحصول على مكافآت! 💰`;
    const url = `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-white text-center flex items-center justify-center gap-2">
        <Users className="w-6 h-6 text-blue-400" />
        دعوة الأصدقاء
      </h2>

      {/* Invite Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl p-4 text-center border border-blue-500/30">
          <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
          <p className="text-3xl font-bold text-white">{user.referrals}</p>
          <p className="text-sm text-gray-400">صديق مدعو</p>
        </div>
        <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-xl p-4 text-center border border-yellow-500/30">
          <Gift className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <p className="text-3xl font-bold text-white">{(user.referrals * 500).toLocaleString()}</p>
          <p className="text-sm text-gray-400">عملة مكتسبة</p>
        </div>
      </div>

      {/* Invite Link */}
      <div className="bg-[#1a1a2e] rounded-xl p-4 border border-white/10">
        <p className="text-sm text-gray-400 mb-2">رابط الدعوة الخاص بك</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-black/30 rounded-lg px-3 py-2 text-sm text-gray-300 truncate font-mono">
            {inviteLink}
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={handleCopy}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Share Button */}
      <Button
        onClick={handleShare}
        className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold py-6"
      >
        <Share2 className="w-5 h-5 mr-2" />
        مشاركة مع الأصدقاء
      </Button>

      {/* Rewards Info */}
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-xl p-4 border border-green-500/30">
        <div className="flex items-center gap-3 mb-3">
          <Gift className="w-6 h-6 text-green-400" />
          <h3 className="font-bold text-white">المكافآت</h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-300">
          <li className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-400" />
            احصل على <span className="text-yellow-400 font-bold">500</span> عملة لكل صديق يدعوه
          </li>
          <li className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-400" />
            صديقك يحصل على <span className="text-yellow-400 font-bold">100</span> عملة ترحيبية
          </li>
          <li className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-400" />
            لا حدود للدعوات!
          </li>
        </ul>
      </div>

      {/* How to invite */}
      <div className="bg-[#1a1a2e] rounded-xl p-4 border border-white/10">
        <h3 className="font-bold text-white mb-3">كيف تدعو أصدقاء؟</h3>
        <ol className="space-y-3 text-sm text-gray-300">
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-blue-500/30 text-blue-400 flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
            انسخ رابط الدعوة الخاص بك
          </li>
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-blue-500/30 text-blue-400 flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
            أرسله لأصدقائك على تليجرام
          </li>
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-blue-500/30 text-blue-400 flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
            عندما ينضمون، تحصل على المكافأة!
          </li>
        </ol>
      </div>
    </div>
  );
}
