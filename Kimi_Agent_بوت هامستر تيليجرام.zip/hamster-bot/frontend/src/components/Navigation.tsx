import { Gamepad2, ShoppingCart, Trophy, Users } from 'lucide-react';
import { TabType } from '@/types';

interface NavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const tabs = [
  { id: 'game' as TabType, label: 'اللعبة', icon: Gamepad2 },
  { id: 'upgrades' as TabType, label: 'التحسينات', icon: ShoppingCart },
  { id: 'leaderboard' as TabType, label: 'المتصدرين', icon: Trophy },
  { id: 'friends' as TabType, label: 'الأصدقاء', icon: Users },
];

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#0a0a0f] to-[#1a1a2e] border-t border-white/10 px-2 py-2 z-50">
      <div className="max-w-md mx-auto flex justify-around">
        {tabs.map(tab => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`
                flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all
                ${isActive 
                  ? 'bg-gradient-to-r from-purple-500/30 to-pink-500/30 text-white' 
                  : 'text-gray-400 hover:text-gray-200'
                }
              `}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'text-purple-400' : ''}`} />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
