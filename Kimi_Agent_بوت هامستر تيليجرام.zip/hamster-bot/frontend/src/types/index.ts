export interface User {
  id: number;
  firstName: string;
  username?: string;
  coins: number;
  energy: number;
  maxEnergy: number;
  level: number;
  xp: number;
  coinsPerClick: number;
  energyRegenRate: number;
  referrals: number;
}

export interface ClickResponse {
  coins: number;
  energy: number;
  maxEnergy: number;
  level: number;
  xp: number;
  coinsEarned: number;
  xpEarned: number;
  leveledUp: boolean;
}

export interface UpgradeResponse {
  success: boolean;
  cost: number;
  newCoins: number;
  effects: Record<string, number>;
}

export interface LeaderboardUser {
  user_id: number;
  username: string;
  first_name: string;
  coins: number;
  level: number;
}

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

export type TabType = 'game' | 'upgrades' | 'leaderboard' | 'friends';
